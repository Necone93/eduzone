<?php

// Javni sadržaj Digitalne učionice.
return [
    'ikt-u-savremenom-okruzenju' => [
        'oblast' => 'informatika',
        'naslov' => 'IKT u savremenom okruženju',
        'opis' => 'Saznaj šta su podaci, informacije i informaciono-komunikacione tehnologije, kako računar zapisuje podatke i kakav uticaj IKT ima na društvo.',
        'minuti' => 25,
        'delovi' => [
            [
                'Šta su informaciono-komunikacione tehnologije?',
                [
                    'Ljudi su oduvek prikupljali, obrađivali i razmenjivali podatke: prvo pomoću prstiju, kamenčića i zapisa, a zatim uz računaljke i druga pomagala.',
                    'Danas IKT obuhvata računare, telefone i druge uređaje, kao i mreže i servise koji omogućavaju prikupljanje, obradu, čuvanje, prenos i zaštitu informacija. Zahvaljujući njima, poruka može stići na drugi kraj planete za nekoliko sekundi.'
                ]
            ],
            [
                'Podatak i informacija nisu isto',
                [
                    'Podatak je pojedinačna činjenica: broj, slovo, boja, simbol ili zapis. Informacija nastaje kada podatak protumačimo u određenom kontekstu.',
                    'Na primer, broj 5 sam za sebe ne govori dovoljno. Može da označava ocenu, broj autobusa, peti sprat ili cenu proizvoda. Tek kontekst daje smisao tom podatku.'
                ],
                ['Podatak: zapis bez objašnjenja.', 'Informacija: podatak kome je dat smisao u konkretnoj situaciji.'],
                ['slika' => 'assets/img-ikt-kontekst.jpeg', 'alt' => 'Primeri različitog značenja broja 5 u zavisnosti od konteksta.']
            ],
            [
                'Zašto su računari važni?',
                [
                    'Računari brzo i precizno obrađuju velike količine podataka, automatizuju ponavljajuće poslove, čuvaju digitalne arhive i omogućavaju trenutnu komunikaciju.',
                    'Srećemo ih u obrazovanju, zdravstvu, poslovanju, nauci, industriji, zabavi i telekomunikacijama. Elektronski dnevnik, internet kupovina, medicinski nalazi i videopozivi samo su neki svakodnevni primeri.'
                ],
                ['brzina i preciznost', 'automatizacija zadataka', 'skladištenje i pretraga podataka', 'povezivanje ljudi i uređaja']
            ],
            [
                'Kako računar obrađuje podatke?',
                [
                    'Računar izvršava instrukcije i pri tom prolazi kroz četiri osnovne radnje. Unos dobija preko tastature, miša, mikrofona ili kamere; podatke čuva u memoriji; obrađuje ih u procesoru; a rezultat prikazuje na ekranu, zvučniku ili štampaču.',
                    'U unutrašnjosti računara sve se predstavlja nizovima nula i jedinica. Prisustvo električnog impulsa možemo označiti jedinicom, a odsustvo nulom.'
                ],
                ['ulaz', 'skladištenje', 'obrada', 'izlaz']
            ],
            [
                'Binarni brojevi, bit i bajt',
                [
                    'Binarni sistem ima osnovu 2 i koristi samo cifre 0 i 1. Jedna binarna cifra zove se bit. Sa 8 bitova dobijamo bajt, a osam bitova može da kodira 256 različitih vrednosti.',
                    'Svaka pozicija u binarnom broju predstavlja stepen broja 2. Zato je 1011₂ jednako 1 × 2³ + 0 × 2² + 1 × 2¹ + 1 × 2⁰, odnosno 11 u dekadnom sistemu.'
                ],
                ['1 B = 8 b', '1 KB = 1024 B', '1 MB = 1024 KB', '1 GB = 1024 MB', '1 TB = 1024 GB']
            ],
            [
                'Tekst, kodiranje i Unicode',
                [
                    'Da bi računar prikazao tekst, svakom znaku dodeljuje brojčanu vrednost. ASCII je prvi široko prihvaćen standard za kodiranje osnovnih znakova engleskog alfabeta, cifara i simbola. Sadrži 128 znakova.',
                    'Unicode proširuje tu ideju: svakom znaku iz različitih jezika i pisama daje jedinstvenu kodnu tačku. Zahvaljujući njemu pravilno se prikazuju latinica, ćirilica, kineski znakovi, emotikoni i mnogi drugi simboli. Na internetu se najčešće koristi UTF-8.'
                ],
                [],
                ['slika' => 'assets/img-ascii-tabela.jpeg', 'alt' => 'ASCII tabela sa kodovima znakova.']
            ],
            [
                'Slike, zvuk i video',
                [
                    'Digitalna slika sastoji se od piksela — malih tačaka raspoređenih u redove i kolone. Rezolucija 1920 × 1080 govori koliko piksela ima slika po širini i visini. Boja piksela se najčešće opisuje RGB modelom, kombinovanjem crvene, zelene i plave boje.',
                    'JPEG je pogodan za fotografije, PNG čuva kvalitet i podržava providnost, a GIF se koristi za jednostavne animacije. Zvuk se u računaru čuva kao digitalni signal, dok je video niz slika koje se brzo prikazuju jedna za drugom.'
                ]
            ],
            [
                'IKT, zdravlje i životna sredina',
                [
                    'IKT može doprineti zdravlju kroz medicinsku dijagnostiku, obrazovanje i dostupnost korisnih informacija. Ipak, važno je voditi računa o pravilnom položaju tela, osvetljenju, pauzama od ekrana i vremenu provedenom na internetu.',
                    'Elektronski otpad čine dotrajali uređaji, baterije, kablovi i komponente. Ne odlaže se u običan kontejner: sadrži materijale koji mogu biti štetni, ali se veliki deo može reciklirati.'
                ],
                [],
                ['slika' => 'assets/img-elektronski-otpad.jpeg', 'alt' => 'Elektronski otpad koji treba pravilno odložiti ili reciklirati.']
            ],
        ],
        'zadatak' => 'Objasni razliku između podatka i informacije na jednom sopstvenom primeru. Zatim pretvori binarni broj 11001₂ u dekadni sistem i napiši koje navike pomažu da bezbednije i zdravije koristiš računar.',
        'resenje' => 'Primer: broj 8 je podatak, a „autobus broj 8 stiže za dva minuta” je informacija jer je broj dobio kontekst. Binarni broj 11001₂ je 16 + 8 + 1 = 25. Korisne navike su pravilno sedenje, redovne pauze, odgovarajuće osvetljenje i odlaganje elektronskog otpada na za to predviđena mesta.',
    ],
    'racunarstvo-hardver-i-softver' => [
        'oblast' => 'informatika',
        'naslov' => 'Računarstvo: hardver i softver',
        'opis' => 'Upoznaj fizičke delove računara, uloge CPU-a, RAM-a, diskova i grafičke kartice, kao i razliku između sistemskog i aplikativnog softvera.',
        'minuti' => 25,
        'delovi' => [
            [
                'Hardver: ono što možeš da dodirneš',
                [
                    'Hardver su fizičke komponente računara i elektronskih sistema: tastatura, monitor, miš, procesor, memorija, disk i mnogi drugi delovi. Zajedno omogućavaju unos, obradu, čuvanje i prikaz podataka.',
                    'Softver daje naredbe, a hardver ih izvršava. Zato hardver možemo posmatrati kao fizičku osnovu rada računarskog sistema.'
                ],
                ['ulaz podataka', 'obrada instrukcija', 'skladištenje podataka', 'prikaz rezultata']
            ],
            [
                'CPU — centralna procesorska jedinica',
                [
                    'CPU, odnosno procesor, preuzima instrukcije iz memorije, tumači ih i izvršava potrebne operacije. On koordinira rad drugih komponenti računara.',
                    'Važne karakteristike procesora su broj jezgara, frekvencija i keš memorija. Više jezgara pomaže pri istovremenom radu više programa, frekvencija se izražava u GHz, a keš čuva često korišćene podatke veoma blizu procesora.'
                ],
                ['desktop procesori', 'mobilni procesori', 'integrisani grafički procesori'],
                ['slika' => 'assets/img-hardver-cpu.jpeg', 'alt' => 'Primer centralne procesorske jedinice — CPU.']
            ],
            [
                'RAM i keš memorija',
                [
                    'RAM je radna, prolazna memorija. U njoj se privremeno čuvaju programi i podaci koje procesor trenutno koristi. Kada se računar isključi, sadržaj RAM-a nestaje.',
                    'Keš memorija je još brža i manja memorija za podatke kojima procesor često pristupa. Možeš je zamisliti kao radni sto: najpotrebnije beleške su ti odmah pri ruci, dok su ostale na polici ili u arhivi.'
                ],
                ['RAM: privremeno čuva aktivne podatke', 'keš: ubrzava pristup često korišćenim podacima', 'veći kapacitet RAM-a pomaže pri radu više aplikacija']
            ],
            [
                'HDD i SSD: gde se čuvaju fajlovi?',
                [
                    'Za trajno čuvanje operativnog sistema, programa, dokumenata, fotografija i video-zapisa koriste se diskovi. HDD ima magnetne ploče koje se okreću, dok SSD koristi fleš memoriju i nema pokretne delove.',
                    'SSD je obično brži, tiši i otporniji na udarce. HDD je često povoljniji kada je potreban veliki kapacitet skladišta.'
                ],
                ['HDD: mehanički disk sa rotirajućim pločama', 'SSD: fleš memorija bez pokretnih delova', 'oba uređaja čuvaju podatke i bez napajanja'],
                ['slika' => 'assets/img-hardver-hdd.jpeg', 'alt' => 'Primer uređaja za skladištenje podataka.']
            ],
            [
                'GPU i grafička kartica',
                [
                    'GPU je procesorska jedinica specijalizovana za grafiku. Obrađuje slike, video i 3D sadržaj, pa rasterećuje CPU pri zahtevnim vizuelnim zadacima.',
                    'Integrisana grafika nalazi se u procesoru ili na matičnoj ploči i dovoljna je za osnovne zadatke. Odvojena grafička kartica ugrađuje se kao zasebna komponenta i koristi se za igre, obradu videa i 3D modelovanje.'
                ],
                ['integrisana grafika: manja potrošnja i osnovni zadaci', 'odvojena grafička kartica: veće performanse za zahtevnu grafiku']
            ],
            [
                'Podela hardvera po funkciji',
                [
                    'Uređaje možemo podeliti prema zadatku koji obavljaju. Neki uređaji mogu imati više uloga, ali ova podela pomaže da razumemo tok podataka kroz računar.'
                ],
                ['ulazni: tastatura, miš, mikrofon, kamera, skener', 'izlazni: monitor, štampač, zvučnici, slušalice', 'skladišni: HDD, SSD, USB fleš, memorijska kartica', 'procesorski i memorijski: CPU, GPU, RAM i keš'],
                ['slika' => 'assets/img-hardver-ulaz-izlaz.jpeg', 'alt' => 'Prikaz toka podataka od ulaznih uređaja, preko obrade, do izlaznih uređaja.']
            ],
            [
                'Softver: programi koji upravljaju računarom',
                [
                    'Softver je skup programa i podataka koji računaru daju instrukcije. Operativni sistem je osnovni softver koji povezuje korisnika, aplikacije i hardver. Primeri su Windows, macOS i različite Linux distribucije.',
                    'Sistemski softver uključuje operativni sistem, drajvere, grafički korisnički interfejs i pomoćne programe. Aplikativni softver služi za konkretne korisničke zadatke: pisanje teksta, obradu fotografija, komunikaciju ili igranje igara.'
                ],
                ['sistemski softver: omogućava rad računara', 'aplikativni softver: pomaže korisniku da obavi zadatak', 'primeri aplikacija: Office, Photoshop, Viber, Minecraft']
            ],
        ],
        'zadatak' => 'Zamisli da biraš računar za obradu videa. Napiši koje bi komponente bile posebno važne i objasni zašto. Zatim razvrstaj tastaturu, monitor, SSD i RAM prema njihovoj osnovnoj funkciji.',
        'resenje' => 'Za obradu videa važni su snažan CPU, dovoljno RAM memorije, brz SSD i dobra grafička kartica. Tastatura je ulazni uređaj, monitor je izlazni, SSD je uređaj za skladištenje, a RAM je memorijski uređaj.',
    ],
    'ms-excel-osnove' => [
        'oblast' => 'informatika',
        'naslov' => 'MS Excel — rad sa tabelama, formulama i dijagramima',
        'opis' => 'Nauči osnove rada u Excelu: ćelije i radne listove, unos i formatiranje podataka, formule, funkcije, dijagrame, sortiranje i filtriranje.',
        'minuti' => 35,
        'delovi' => [
            [
                'Uvod u MS Excel',
                [
                    'Excel je program za rad sa tabelama. Radni list se sastoji od kolona označenih slovima, redova označenih brojevima i ćelija koje nastaju na njihovom preseku. Adresa ćelije je spoj oznake kolone i reda, na primer A1.',
                    'Jedna radna sveska može sadržati više radnih listova. U prozoru Excela nalaze se naslovna linija, meniji, alatke, linija za formule, radna površina, trake za pomeranje i statusna linija.'
                ],
                ['kolona: A, B, C…', 'red: 1, 2, 3…', 'ćelija: presek kolone i reda, na primer B4'],
                ['slika' => 'assets/img-excel-prozor.png', 'alt' => 'Osnovni elementi prozora programa MS Excel.'],
                [['tekst' => 'Pogledaj video: uvod u MS Excel', 'url' => 'https://drive.google.com/file/d/1cJ0DqZSEv8jldMelOG1c_rrflcoss6UM/view?usp=drive_link']]
            ],
            [
                'Kretanje i uređivanje radnog lista',
                [
                    'Po radnom listu se krećeš mišem, strelicama na tastaturi i kombinacijama tastera. Novi radni list možeš dodati, obrisati, preimenovati, premestiti ili kopirati preko menija koji se otvara desnim klikom na karticu lista.',
                    'Komandom Freeze Panes možeš zamrznuti zaglavlje tabele kako bi ostalo vidljivo pri pomeranju. Redove i kolone možeš sakriti pomoću Hide, ponovo prikazati pomoću Unhide, promeniti im širinu ili visinu i dodati nove pomoću Insert.'
                ],
                ['Freeze Panes: zaglavlje ostaje vidljivo', 'Hide / Unhide: sakrij ili prikaži redove i kolone', 'Copy, Cut i Paste: kopiranje i premeštanje sadržaja'],
                [],
                [
                    ['tekst' => 'Video primer: zamrzavanje i skrivanje redova/kolona', 'url' => 'https://drive.google.com/file/d/18Q5FhlYGgAybfa6XYpyooWHgQYtM8a2S/view?usp=sharing'],
                    ['tekst' => 'Video primer: umetanje, kopiranje i premeštanje', 'url' => 'https://drive.google.com/file/d/14IESiTIx6iwlOSvVbG8Q4F_q5uibPqdt/view?usp=sharing']
                ]
            ],
            [
                'Unos podataka i automatsko popunjavanje',
                [
                    'Ćelija može sadržati tekst, broj, datum, vreme, logičku vrednost ili formulu. Tekst se podrazumevano poravnava ulevo, a broj udesno. Ako je kolona preuska za broj, Excel prikazuje znakove #, ali je vrednost i dalje sačuvana.',
                    'Za broj koji mora ostati tekst, na primer šifru sa početnom nulom, ispred njega upiši apostrof. Automatsko popunjavanje koristi mali kvadratić u donjem desnom uglu izabrane ćelije: povlačenjem možeš brzo nastaviti niz brojeva, dana ili meseci.'
                ],
                ['tekst: Enter potvrđuje unos', 'broj kao tekst: dodaj apostrof ispred vrednosti', 'Auto Fill: povuci ručicu za popunjavanje niza'],
                [],
                [['tekst' => 'Video primer: automatsko popunjavanje liste', 'url' => 'https://drive.google.com/file/d/1wxMmDTC8GzjKBeVUXmYfL6IsWFg0FaK1/view?usp=sharing']]
            ],
            [
                'Formatiranje ćelija i radnih listova',
                [
                    'Formatiranje čini tabelu preglednijom. Dijalog Format Cells možeš otvoriti desnim klikom ili prečicom Ctrl + 1. U njemu podešavaš izgled brojeva, poravnanje, font, ivice, boju pozadine i zaštitu ćelija.',
                    'Number služi za broj, valutu, datum i procenat. Alignment podešava položaj sadržaja i spajanje ćelija. Font bira izgled slova, Border ivice, Fill boju pozadine, a Protection zaključavanje ćelija.'
                ],
                ['Number', 'Alignment', 'Font', 'Border', 'Fill', 'Protection'],
                ['slika' => 'assets/img-excel-formatiranje.png', 'alt' => 'Dijalog za formatiranje ćelija u programu Excel.'],
                [['tekst' => 'Video primer: formatiranje ćelija', 'url' => 'https://drive.google.com/file/d/1vPXGu3iXSyCh9NioqZKRu4jWBIy1hMXr/view?usp=sharing']]
            ],
            [
                'Formule i reference na ćelije',
                [
                    'Formula u Excelu uvek počinje znakom jednakosti (=). Može koristiti brojeve, operatore i adrese ćelija. Na primer, srednja vrednost brojeva iz A1, B1 i C1 može se izračunati formulom =(A1+B1+C1)/3.',
                    'Relativne reference se menjaju kada kopiraš formulu na drugo mesto. Apsolutna referenca ima znak $ ispred kolone i reda, na primer $A$1, i ostaje ista pri kopiranju formule. Taster F4 pomaže pri dodavanju znaka $. '
                ],
                ['aritmetički operatori: +, -, *, /, %, ^', 'tekstualni operator: &', 'uporedni operatori: =, <, <=, >, >=, <>', 'relativna referenca: A1; apsolutna referenca: $A$1'],
                [],
                [
                    ['tekst' => 'Video primer: unos formula', 'url' => 'https://drive.google.com/file/d/1JaOUtICGGcKWeFzkmJmuwIDWKOqthuzH/view?usp=sharing'],
                    ['tekst' => 'Video primer: relativne reference', 'url' => 'https://drive.google.com/file/d/1_bNpeWrGFZTvuddA6MoELJc0z_jKm4a6/view?usp=sharing'],
                    ['tekst' => 'Video primer: apsolutne reference', 'url' => 'https://drive.google.com/file/d/1bgS0tsmLczscQBFTMAWi5op9_gOVq38w/view?usp=sharing']
                ]
            ],
            [
                'Ugrađene funkcije',
                [
                    'Funkcija je ugrađena formula koja obavlja proračun ili vraća određenu informaciju. Umesto formule =B4+B5+B6 možeš koristiti =SUM(B4:B6). Excel ima Function Wizard, odnosno čarobnjak za funkcije, koji pomaže pri izboru i unosu argumenata.',
                    'Za početak su najkorisnije funkcije SUM, AVERAGE, MIN, MAX, COUNT, COUNTA, IF i COUNTIF.'
                ],
                ['=SUM(B4:B6)', '=AVERAGE(A1:A10)', '=MIN(A1:A10)', '=MAX(A1:A10)', '=COUNT(A1:A10)'],
                []
            ],
            [
                'Dijagrami, sortiranje i filtriranje',
                [
                    'Dijagram vizuelno prikazuje podatke i olakšava uočavanje odnosa i promena. Nakon što označiš podatke, na kartici Insert biraš tip dijagrama. Česti izbori su stubasti, linijski, kružni i horizontalni stubasti dijagram.',
                    'Sortiranje raspoređuje tekst, brojeve ili datume željenim redosledom. Filtriranje privremeno prikazuje samo redove koji zadovoljavaju postavljeni uslov, dok ostale ne briše već ih sakriva.'
                ],
                ['Column: vertikalni stubići', 'Line: praćenje promena kroz vreme', 'Pie: udeli i procenti', 'Sort & Filter: rad sa većim tabelama'],
                ['slika' => 'assets/img-excel-dijagram.png', 'alt' => 'Primer tipova dijagrama koji se mogu napraviti u Excelu.'],
                [['tekst' => 'Video primer: izrada dijagrama', 'url' => 'https://drive.google.com/file/d/1POX86TakReqXoU8EF644rg4ZrqjI-l7x/view?usp=sharing']]
            ],
        ],
        'zadatak' => 'Napravi tabelu sa pet učenika i njihove tri ocene. Izračunaj prosečnu ocenu pomoću AVERAGE, oboji zaglavlje, sortiraj učenike po proseku od najvećeg ka najmanjem i napravi stubasti dijagram proseka.',
        'resenje' => 'U koloni za prosek unesi formulu poput =AVERAGE(B2:D2) i kopiraj je naniže. Označi zaglavlje i primeni formatiranje, zatim izaberi Data → Sort po koloni prosek, opadajuće. Za dijagram označi imena i proseke, pa izaberi Insert → Column chart.',
    ],
    'racunarska-grafika-gimp' => [
        'oblast' => 'informatika',
        'naslov' => 'Računarska grafika i GIMP',
        'opis' => 'Upoznaj piksele, rezoluciju, formate slika, razliku između rasterske i vektorske grafike, pa primeni osnovne GIMP alate za obradu slike.',
        'minuti' => 35,
        'delovi' => [
            [
                'Piksel, rezolucija i boja',
                [
                    'Računarska grafika obuhvata stvaranje, obradu, doradu i vizuelizaciju slika i animacija uz pomoć računara. Pri čuvanju slike želimo što verniji prikaz uz što manje zauzetog prostora.',
                    'Piksel je najmanji element rasterske slike. Slika se sastoji od mreže piksela; njihov broj određuje rezoluciju, a dubina boje određuje koliko različitih nijansi može biti prikazano. U RGB modelu boje nastaju kombinovanjem crvene, zelene i plave svetlosti.'
                ],
                ['više piksela: više detalja i veći fajl', 'dubina boje: više mogućih nijansi', 'RGB: red, green, blue']
            ],
            [
                'Rasterska i vektorska grafika',
                [
                    'Rasterska slika čuva podatke za svaki piksel. Odlična je za fotografije, ali pri velikom uvećavanju gubi kvalitet i postaje „kockasta”.',
                    'Vektorska grafika opisuje sliku pomoću tačaka, linija, krivih i geometrijskih oblika. Lako se povećava bez gubitka kvaliteta, pa je pogodna za logotipe, ikone i ilustracije.'
                ],
                ['raster: fotografije i pikseli', 'vektor: oblici i matematički opis', 'raster se pri uvećanju može zamutiti; vektor ostaje oštar'],
                ['slika' => 'assets/img-gimp-raster-vektor.jpeg', 'alt' => 'Poređenje rasterskog i vektorskog prikaza.']
            ],
            [
                'Formati slika',
                [
                    'Izbor formata utiče na kvalitet, veličinu fajla i mogućnosti slike. RAW čuva neobrađene podatke senzora, BMP čuva piksele bez kompresije, a GIF koristi najviše 256 boja i podržava jednostavne animacije.',
                    'JPEG koristi kompresiju sa gubitkom i najčešće je dobar izbor za fotografije. PNG koristi kompresiju bez gubitka, podržava mnogo boja i providnost, dok je MPEG namenjen komprimovanju videa.'
                ],
                ['RAW: najviše podataka, bez kompresije', 'BMP: velika datoteka bez kompresije', 'JPEG: fotografije i kompresija sa gubitkom', 'PNG: bez gubitka i podrška za providnost', 'GIF: ograničena paleta i animacija']
            ],
            [
                'GIMP: program za obradu slika',
                [
                    'GIMP je besplatan program otvorenog koda za obradu rasterskih slika. Možeš ga koristiti za retuširanje, crtanje, promenu formata, podešavanje dimenzija i rad sa slojevima.',
                    'U nastavku su osnovni postupci koje ćeš koristiti pri pripremi slike za veb, školsku prezentaciju ili objavu na mreži.'
                ],
                ['otvoren kod', 'obrada i retuširanje slike', 'podrška za slojeve i maske'],
                [],
                [['tekst' => 'Preuzmi GIMP za Windows', 'url' => 'https://download.gimp.org/gimp/v2.10/windows/gimp-2.10.38-setup-1.exe']]
            ],
            [
                'Promena dimenzija slike — Scale',
                [
                    'Kada je slika prevelika, u GIMP-u koristi Image → Scale Image. U prozoru unesi novu širinu ili visinu, a ikona lanca čuva odnos stranica kako se slika ne bi razvukla.',
                    'Ako promeniš širinu na 600 px uz zaključan lanac, GIMP automatski prilagođava visinu. Nakon izmene koristi Export, odaberi naziv i mesto čuvanja, pa po potrebi podesi kvalitet JPEG slike.'
                ],
                ['Image → Scale Image', 'zadrži zaključan lanac za pravilan odnos širine i visine', 'Export čuva kopiju u izabranom formatu'],
                ['slika' => 'assets/img-gimp-scale.jpeg', 'alt' => 'Prozor Scale Image u programu GIMP.']
            ],
            [
                'Rezanje slike — Crop',
                [
                    'Crop služi da ukloniš nepotrebne ivice ili da istakneš važan deo fotografije. Izaberi alatku Crop, prevuci okvir preko željenog dela slike, zatim po potrebi fino prilagodi ivice i pritisni Enter.',
                    'Ako želiš da odustaneš, pritisni Esc. Drugi način je da prvo napraviš izbor alatkom Rectangle Select, a zatim primeniš rezanje na selekciju.'
                ],
                ['Crop: označi deo slike koji želiš da zadržiš', 'Enter: potvrđuje rezanje', 'Esc: odustaje od postupka', 'Rectangle Select: pravi pravougaonu selekciju'],
                ['slika' => 'assets/img-gimp-crop.jpeg', 'alt' => 'Primer alata Crop i označenog dela slike u GIMP-u.']
            ],
            [
                'Rotacija, slojevi i maske sloja',
                [
                    'Komandama Rotate i Flip možeš promeniti orijentaciju slike. Slojeve možeš zamisliti kao prozirne folije: pozadina je na donjem sloju, a tekst, crteži ili druge slike mogu biti na slojevima iznad nje.',
                    'Maska sloja omogućava selektivnu providnost. Dodaje se komandom Layer → Add Layer Mask. Na maski bela boja otkriva sadržaj sloja, crna ga sakriva, a nijanse sive daju delimičnu providnost.'
                ],
                ['Layer → New Layer: dodavanje sloja', 'pomeranjem sloja menjaš redosled prikaza', 'bela maska: sadržaj je vidljiv', 'crna maska: sadržaj je skriven', 'siva maska: delimična providnost'],
                ['slika' => 'assets/img-gimp-layer-mask.png', 'alt' => 'Dijalog za dodavanje maske sloja u GIMP-u.']
            ],
        ],
        'zadatak' => 'U GIMP-u otvori jednu fotografiju. Napravi kopiju, smanji joj širinu na 800 px sa sačuvanim odnosom stranica, iseci nepotrebne ivice i izvezi je kao JPEG. Zatim na kopiji dodaj novi sloj i isprobaj masku sloja pomoću crne, bele i sive boje.',
        'resenje' => 'Koristi Image → Scale Image, unesi širinu 800 px uz zaključan lanac, zatim izaberi Crop i potvrdi Enterom. Sačuvaj preko File → Export As. Novi sloj dodaješ preko Layer → New Layer, a masku preko Layer → Add Layer Mask; bela otkriva, crna skriva, a siva delimično prikazuje sloj.',
    ],
    'uvod-u-php' => [
        'oblast' => 'web-programiranje',
        'naslov' => 'Uvod u PHP',
        'opis' => 'Nauči šta je PHP, kako se pokreće na lokalnom serveru i savladaj osnove sintakse, promenljivih, operatora i uslovnih naredbi.',
        'minuti' => 25,
        'delovi' => [
            [
                'Šta je PHP?',
                [
                    'PHP je programski jezik za razvoj veb aplikacija. Izvršava se na serveru, a rezultat njegovog rada se zatim šalje pregledaču. Može se kombinovati sa HTML-om da bi sajtovi bili dinamični i interaktivni.',
                    'Za rad na svom računaru koristićemo lokalni Apache server iz paketa XAMPP. PHP fajlove čuvamo u svom projektnom folderu unutar putanje C:\\xampp\\htdocs, a zatim u XAMPP-u pokrećemo Apache.'
                ],
                ['PHP se izvršava na serveru', 'PHP fajlovi imaju ekstenziju .php', 'XAMPP obezbeđuje lokalni Apache server'],
                ['slika' => 'assets/img-php-xampp.png', 'alt' => 'XAMPP kontrolni panel za pokretanje lokalnog Apache servera.'],
                [['tekst' => 'Preuzmi XAMPP', 'url' => 'https://www.apachefriends.org/']]
            ],
            [
                'PHP oznake i prvi program',
                [
                    'PHP kod se piše između oznaka <?php i ?>. Te oznake govore serveru koji deo dokumenta treba da obradi kao PHP. Kod možeš umetnuti u HTML dokument, ali fajl mora imati ekstenziju .php.',
                    'Najjednostavniji način da proveriš da li lokalni server radi jeste program koji ispisuje poruku Hello World.'
                ],
                ['otvori editor za kod', 'napravi fajl index.php u svom projektnom folderu', 'pokreni Apache u XAMPP-u', 'otvori projekat u pregledaču preko localhost-a']
            ],
            [
                'Promenljive i tipovi podataka',
                [
                    'Promenljiva je mesto u memoriji u koje privremeno smeštamo podatak. U PHP-u svaka promenljiva počinje znakom $, a vrednost joj dodeljujemo znakom =.',
                    'Ime promenljive ne može početi brojem ili posebnim znakom, osim znaka $ koji označava samu promenljivu. Promenljiva može čuvati tekst, broj, logičku vrednost i druge tipove podataka.'
                ],
                ['$ime = "Ana";', '$godine = 16;', '$aktivan = true;', 'operator = dodeljuje vrednost promenljivoj']
            ],
            [
                'Aritmetički i poredbеni operatori',
                [
                    'Operatori omogućavaju da računamo, poredimo vrednosti i upravljamo tokom programa. Aritmetički operatori služe za sabiranje, oduzimanje, množenje, deljenje i određivanje ostatka pri deljenju.',
                    'Poredbеni operatori se najčešće koriste u uslovnim naredbama. Njima proveravamo da li su dve vrednosti jednake, različite, veće ili manje jedna od druge.'
                ],
                ['$a + $b: sabiranje', '$a - $b: oduzimanje', '$a * $b: množenje', '$a / $b: deljenje', '$a % $b: ostatak pri deljenju'],
                ['slika' => 'assets/img-php-operatori.png', 'alt' => 'Pregled aritmetičkih operatora u PHP-u.']
            ],
            [
                'Uslovne naredbe: if i else',
                [
                    'Uslovna naredba omogućava programu da donese odluku. Kod unutar bloka if izvršava se samo kada je postavljeni uslov tačan.',
                    'Komanda else određuje alternativu: njen kod se izvršava kada uslov iz if dela nije ispunjen. Tako program može drugačije reagovati na različite vrednosti.'
                ],
                ['if: izvršava kod kada je uslov tačan', 'else: izvršava alternativni kod', 'uslov se piše u zagradi, a kod u vitičastim zagradama'],
                ['slika' => 'assets/img-php-if-else.png', 'alt' => 'Primer strukture uslovne naredbe if i else u PHP-u.']
            ],
        ],
        'kod' => <<<'PHP'
<?php
$ime = 'Ana';
$godine = 16;

echo 'Zdravo, ' . $ime . '!';

if ($godine >= 18) {
    echo ' Punoletna osoba.';
} else {
    echo ' Maloletna osoba.';
}
?>
PHP,
        'zadatak' => 'Napravi fajl index.php. U promenljive upiši svoju satnicu, broj radnih sati i ukupnu prodaju. Izračunaj platu tako da je satnica za rad u prodaji 1,5 puta veća, dodaj 10% provizije od prodaje i bonus od 1 000 ako je prodaja veća od 1 000.',
        'resenje' => 'Primer: $satnica = 500; $sati = 8; $prodaja = 1200; $plata = $satnica * 1.5 * $sati + $prodaja * 0.10; if ($prodaja > 1000) { $plata += 1000; } Na kraju ispiši rezultat pomoću echo.',
    ],
    'php-nizovi-i-petlje' => [
        'oblast' => 'web-programiranje',
        'naslov' => 'PHP: nizovi i petlje',
        'opis' => 'Nauči kako se podaci čuvaju u indeksiranim, asocijativnim i višedimenzionalnim nizovima, a zatim ih obradi pomoću for, while, do-while i foreach petlji.',
        'minuti' => 35,
        'delovi' => [
            [
                'Indeksirani nizovi',
                [
                    'Niz je promenljiva koja čuva više vrednosti. Indeksirani niz ima brojeve kao indekse, počevši od 0. Možeš napraviti prazan niz ili ga odmah popuniti vrednostima.',
                    'Elementu pristupaš preko njegovog indeksa, na primer $studenti[0]. Novi element dodaješ pomoću $studenti[] = vrednost ili funkcijom array_push, a uklanjaš funkcijom unset.'
                ],
                ['prazan niz: $niz = [];', 'prvi element ima indeks 0', 'dodavanje: $niz[] = "nova vrednost"', 'brisanje: unset($niz[2])'],
                ['slika' => 'assets/img-php-nizovi.png', 'alt' => 'Primer definisanja praznog niza u PHP-u.']
            ],
            [
                'Asocijativni nizovi',
                [
                    'Asocijativni niz povezuje tekstualni ključ sa vrednošću. Takav zapis je pregledan kada čuvaš osobine neke osobe, proizvoda ili drugog objekta.',
                    'Vrednosti čitaš preko ključa, na primer $marko["age"]. Novi podatak dodaješ tako što napišeš novi ključ i dodeliš mu vrednost, a uklanjaš ga pomoću unset sa odgovarajućim ključem.'
                ],
                ['ključ-vrednost parovi', 'primer ključeva: ime, godine, boja', 'pristup vrednosti: $osoba["ime"]'],
                ['slika' => 'assets/img-php-asocijativni-niz.png', 'alt' => 'Primer asocijativnog niza sa podacima o osobi.']
            ],
            [
                'Korisne operacije nad nizovima',
                [
                    'Funkcija explode pretvara string u niz tako što ga deli prema zadatom graničniku. Na primer, explode(".", "mojaskripta.txt") daje odvojene delove naziva fajla i ekstenzije.',
                    'Funkcija implode radi suprotno: spaja elemente niza u jedan string. array_slice izdvaja deo niza, dok se za sortiranje mogu koristiti funkcije poput sort ili ksort, u zavisnosti od načina na koji želiš da poređaš podatke.'
                ],
                ['explode: string → niz', 'implode: niz → string', 'array_slice: izdvaja deo niza', 'sort / ksort: uređivanje elemenata']
            ],
            [
                'Višedimenzionalni nizovi',
                [
                    'Višedimenzionalni niz je niz koji u sebi ima druge nizove. Koristan je kada želiš da čuvaš podatke za više osoba, proizvoda ili zapisa, a svaki od njih ima više osobina.',
                    'Za pristup podatku koristiš više ključeva ili indeksa. Na primer, $studenti["Marija"]["age"] pristupa Marijinim godinama.'
                ],
                ['nizovi unutar nizova', 'pogodni za tabele podataka', 'pristup: $studenti["Marija"]["age"]']
            ],
            [
                'for petlja',
                [
                    'for petlju koristiš kada znaš koliko puta treba izvršiti određeni deo koda. Ona sadrži početnu vrednost brojača, uslov za nastavak rada i korak kojim se brojač menja.',
                    'Petlja se često kombinuje sa nizom: count($niz) govori koliko elemenata niz ima, pa preko indeksa možeš proći kroz svaki njegov element.'
                ],
                ['inicijalizacija: $i = 0', 'uslov: $i < 5', 'promena brojača: $i++', 'završava se kada uslov postane netačan'],
                ['slika' => 'assets/img-php-for-petlja.png', 'alt' => 'Osnovna struktura for petlje u PHP-u.']
            ],
            [
                'while i do-while petlje',
                [
                    'while petlja proverava uslov pre izvršavanja tela petlje. Izvršava se sve dok je uslov tačan, zato u telu petlje moraš menjati vrednost koja utiče na uslov da ne bi nastala beskonačna petlja.',
                    'do-while prvo izvrši kod, a tek zatim proverava uslov. Zato se kod u do-while petlji izvrši najmanje jednom, čak i ako je uslov na početku netačan.'
                ],
                ['while: provera pre izvršavanja', 'do-while: provera nakon izvršavanja', 'uvek menjaj brojač ili uslov u telu petlje']
            ],
            [
                'foreach petlja',
                [
                    'foreach je najjednostavniji izbor kada prolaziš kroz sve elemente niza. Možeš uzeti samo vrednost svakog elementa ili istovremeno i ključ i vrednost.',
                    'Kod višedimenzionalnih nizova foreach ti omogućava da redom obradiš svaki zapis, na primer podatke o zaposlenima i njihove plate.'
                ],
                ['foreach ($niz as $vrednost)', 'foreach ($niz as $kljuc => $vrednost)', 'radi sa nizovima i objektima']
            ],
        ],
        'kod' => <<<'PHP'
<?php
$zaposleni = [
    ['ime' => 'Ana', 'pozicija' => 'Dizajner', 'plata' => 120000],
    ['ime' => 'Marko', 'pozicija' => 'Programer', 'plata' => 150000],
];

foreach ($zaposleni as $osoba) {
    $mesecnaPlata = $osoba['plata'] / 12;
    echo $osoba['ime'] . ' radi kao ' . $osoba['pozicija']
        . ', sa mesečnim prihodom od ' . $mesecnaPlata . " evra.<br>";
}
?>
PHP,
        'zadatak' => 'Napravi fajl mesecni_prihodi/index.php. Kreiraj višedimenzionalni niz sa najmanje tri zaposlena. Za svakog upiši ime, poziciju i godišnju platu. Pomoću foreach petlje ispiši ime, poziciju i mesečni prihod svakog zaposlenog.',
        'resenje' => 'Prođi kroz niz pomoću foreach ($zaposleni as $osoba). Mesečni prihod dobijaš formulom $osoba["plata"] / 12, a zatim pomoću echo ispiši podatke iz ključeva ime, pozicija i plata.',
    ],
    'php-funkcije' => [
        'oblast' => 'web-programiranje',
        'naslov' => 'PHP funkcije',
        'opis' => 'Organizuj program u ponovo upotrebljive celine, prosleđuj argumente funkcijama, koristi podrazumevane vrednosti i vraćaj rezultat pomoću return naredbe.',
        'minuti' => 35,
        'delovi' => [
            [
                'Zašto koristimo funkcije?',
                [
                    'Funkcija je imenovana celina koda koja obavlja jedan određeni zadatak. Umesto da isti kod pišeš više puta, funkciju napišeš jednom, a zatim je pozivaš kada ti je potrebna.',
                    'Dobar naziv funkcije govori šta ona radi. Na primer, izracunajProsek jasnije opisuje zadatak od naziva funkcija1.'
                ],
                ['manje ponavljanja koda', 'pregledniji program', 'lakše testiranje i ispravljanje grešaka']
            ],
            [
                'Definisanje i pozivanje funkcije',
                [
                    'Funkciju definišeš ključnom reči function, zatim njenim nazivom, zagradama i blokom koda u vitičastim zagradama. Kod iz funkcije se ne izvršava dok je ne pozoveš.',
                    'Poziv funkcije piše se njenim imenom i zagradama, na primer pozdrav().'
                ],
                ['function pozdrav() { ... }', 'poziv: pozdrav();', 'naziv funkcije neka opisuje njen zadatak']
            ],
            [
                'Argumenti i parametri',
                [
                    'Parametar je promenljiva u definiciji funkcije, a argument je konkretna vrednost koju prosleđuješ prilikom poziva. Tako jedna funkcija može raditi sa različitim podacima.',
                    'Na primer, funkcija pozdrav($ime) može biti pozvana kao pozdrav("Ana") ili pozdrav("Marko").'
                ],
                ['parametar: $ime u definiciji funkcije', 'argument: "Ana" pri pozivu funkcije', 'funkcija može imati više parametara']
            ],
            [
                'Vraćanje rezultata',
                [
                    'Naredba return završava rad funkcije i vraća vrednost mestu gde je funkcija pozvana. Rezultat možeš sačuvati u promenljivoj, prikazati ili koristiti u daljem računanju.',
                    'Funkcija koja računa prosek ne treba sama da ispisuje rezultat; bolje je da ga vrati, kako bi se rezultat kasnije koristio na više načina.'
                ],
                ['return vraća vrednost', 'rezultat funkcije možeš dodeliti promenljivoj', 'jedna funkcija treba da ima jasan zadatak']
            ],
            [
                'Podrazumevane vrednosti parametara',
                [
                    'Parametru možeš postaviti podrazumevanu vrednost. Ona se koristi kada prilikom poziva funkcije ne proslediš odgovarajući argument. To je korisno kada funkcija ima uobičajeno ponašanje koje povremeno želiš da promeniš.',
                    'Na primer, funkcija ispisiPoruku($poruka, $boja = "plava") koristiće plavu boju ako drugi argument izostane, ali možeš je pozvati i sa drugom bojom.'
                ],
                ['podrazumevana vrednost piše se u definiciji parametra', 'argument bez podrazumevane vrednosti ide pre opcionog argumenta', 'poziv može imati manje argumenata od broja opcionih parametara']
            ],
            [
                'Promenljive unutar i izvan funkcije',
                [
                    'Promenljiva napravljena unutar funkcije obično je dostupna samo u toj funkciji. To se zove lokalni opseg važenja. Takav pristup sprečava da različiti delovi programa slučajno menjaju iste podatke.',
                    'Kada funkciji treba podatak, češće je bolje proslediti ga kao argument i vratiti rezultat, nego oslanjati se na globalne promenljive. Tako je funkcija jasnija i lakša za ponovnu upotrebu.'
                ],
                ['lokalna promenljiva: dostupna samo u funkciji', 'argumenti unose podatke u funkciju', 'return iznosi rezultat iz funkcije']
            ],
        ],
        'kod' => <<<'PHP'
<?php
function izracunajProsek($prva, $druga, $treca) {
    return ($prva + $druga + $treca) / 3;
}

$prosek = izracunajProsek(5, 4, 5);
echo 'Prosek je: ' . $prosek;
?>
PHP,
        'zadatak' => 'Napiši funkciju cenaSaPopustom koja prima početnu cenu i procenat popusta, a vraća cenu nakon popusta. Pozovi je za najmanje dva proizvoda i ispiši rezultat.',
        'resenje' => 'Funkcija može imati oblik function cenaSaPopustom($cena, $popust) { return $cena - ($cena * $popust / 100); }. Pozovi je, na primer, sa cenaSaPopustom(2500, 20).',
    ],
    'php-html-forme' => [
        'oblast' => 'web-programiranje',
        'naslov' => 'PHP i HTML forme: GET i POST',
        'opis' => 'Poveži HTML formu sa PHP-om, preuzmi podatke koje korisnik unosi, proveri ih i bezbedno prikaži rezultat.',
        'minuti' => 40,
        'delovi' => [
            [
                'Čemu služe HTML forme?',
                [
                    'Forma omogućava korisniku da unese podatke: ime, e-adresu, poruku, izbor sa liste i druge vrednosti. Kada korisnik klikne na dugme za slanje, pregledač šalje podatke na adresu navedenu u atributu action.',
                    'Svako polje forme mora imati name atribut. PHP koristi taj naziv da bi pronašao poslatu vrednost.'
                ],
                ['form: okvir za polja i dugme', 'input: unos teksta ili broja', 'name: naziv pod kojim PHP prima vrednost', 'button type="submit": šalje formu']
            ],
            [
                'GET metoda',
                [
                    'Kod GET metode podaci se vide u adresnoj traci kao parametri URL-a. Dobra je za pretragu, filtriranje i linkove koje korisnik može sačuvati ili podeliti.',
                    'U PHP-u podatke preuzimaš kroz superglobalni niz $_GET, na primer $_GET["pojam"].'
                ],
                ['podaci su vidljivi u URL-u', 'pogodno za pretragu i filtere', 'čitanje: $_GET["naziv"]']
            ],
            [
                'POST metoda',
                [
                    'Kod POST metode podaci se šalju u telu HTTP zahteva i ne pojavljuju se u adresnoj traci. Koristi je za forme koje menjaju podatke ili sadrže informacije koje ne želiš da budu deo URL-a.',
                    'U PHP-u podatke preuzimaš kroz $_POST. Iako POST skriva podatke iz URL-a, za stvarno osetljive podatke i dalje je obavezan HTTPS i dobra zaštita aplikacije.'
                ],
                ['podaci nisu deo URL-a', 'čitanje: $_POST["naziv"]', 'pogodno za prijavu, registraciju i slanje poruka']
            ],
            [
                'Provera i bezbedan ispis',
                [
                    'Pre upotrebe vrednosti proveri da li je forma poslata i da li polje ima vrednost. Funkcija isset proverava da li promenljiva postoji, a trim uklanja nepotrebne razmake sa početka i kraja teksta.',
                    'Kada prikazuješ korisnički unos u HTML-u, koristi htmlspecialchars. Ona sprečava da sadržaj unosa bude protumačen kao HTML kod.'
                ],
                ['isset: proverava da li podatak postoji', 'trim: uklanja višak razmaka', 'htmlspecialchars: bezbedno prikazuje tekst u HTML-u']
            ],
            [
                'Validacija unosa',
                [
                    'Validacija proverava da li podaci imaju očekivani oblik pre nego što ih program upotrebi. HTML atributi required, type="email", min i max pomažu korisniku pri unosu, ali PHP mora ponovo proveriti podatke na serveru.',
                    'Za e-adresu možeš koristiti filter_var($email, FILTER_VALIDATE_EMAIL), a za brojeve is_numeric. Kada podatak nije ispravan, prikaži jasnu poruku i nemoj obrađivati ostatak zadatka.'
                ],
                ['HTML provera poboljšava korisničko iskustvo', 'PHP provera je obavezna na serveru', 'is_numeric proverava broj', 'filter_var može proveriti e-adresu']
            ],
            [
                'Rad sa više polja i porukama o grešci',
                [
                    'Forma često ima više polja, pa je pregledno da za svako sačuvaš proverenu vrednost i pripadajuću poruku o grešci. Tek kada nema grešaka, nastavi sa računanjem, čuvanjem ili slanjem podataka.',
                    'Ako ponovo prikažeš formu posle greške, možeš u polja vratiti prethodno unete bezbedno obrađene vrednosti. Tako korisnik ne mora sve da unosi ponovo.'
                ],
                ['za svako polje napravi posebnu proveru', 'poruka treba da objasni šta treba ispraviti', 'sačuvaj prethodno unete vrednosti kada forma nije ispravna']
            ],
        ],
        'kod' => <<<'PHP'
<form method="post" action="">
  <label for="ime">Tvoje ime</label>
  <input id="ime" name="ime" required>
  <button type="submit">Pošalji</button>
</form>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ime = trim($_POST['ime'] ?? '');
    if ($ime !== '') {
        echo '<p>Zdravo, ' . htmlspecialchars($ime, ENT_QUOTES, 'UTF-8') . '!</p>';
    }
}
?>
PHP,
        'zadatak' => 'Napravi formu za računanje kvadrata broja. Korisnik unosi broj, forma koristi POST metodu, a PHP nakon slanja prikazuje njegov kvadrat. Proveri da li je uneta vrednost broj.',
        'resenje' => 'Polju daj name="broj". Posle slanja preuzmi $_POST["broj"] i proveri is_numeric($broj). Ako je vrednost broj, ispiši $broj * $broj.',
    ],
    'php-sesije' => [
        'oblast' => 'web-programiranje',
        'naslov' => 'PHP sesije i čuvanje podataka',
        'opis' => 'Saznaj kako PHP pamti podatke između više stranica pomoću sesija, kako se razlikuju od kolačića i kako se podaci pravilno postavljaju i brišu.',
        'minuti' => 35,
        'delovi' => [
            [
                'Problem pamćenja podataka',
                [
                    'HTTP je bezdržavni protokol: svako novo učitavanje stranice posmatra se kao zaseban zahtev. Zbog toga obična promenljiva nestaje čim se završi izvršavanje PHP skripte.',
                    'Sesija omogućava da server poveže više zahteva istog korisnika i sačuva podatke, na primer ime prijavljenog korisnika, korpu za kupovinu ili izabrane postavke.'
                ],
                ['obične PHP promenljive traju samo tokom jednog zahteva', 'sesija povezuje više stranica istog korisnika', 'sesija čuva podatke na serveru']
            ],
            [
                'Pokretanje i upotreba sesije',
                [
                    'Sesija se pokreće naredbom session_start() i ona mora biti pozvana pre bilo kakvog HTML ispisa. Podaci se čuvaju u superglobalnom nizu $_SESSION.',
                    'Na primer, $_SESSION["ime"] = "Ana" čuva vrednost koju možeš pročitati i na drugoj stranici sa $_SESSION["ime"].'
                ],
                ['session_start() ide na početak PHP fajla', 'upis: $_SESSION["ime"] = "Ana"', 'čitanje: $_SESSION["ime"]']
            ],
            [
                'Odjava i brisanje podataka',
                [
                    'Pojedinačnu vrednost iz sesije uklanjaš pomoću unset, na primer unset($_SESSION["ime"]). Kada želiš da korisnika potpuno odjaviš, koristi session_destroy().',
                    'Posle promene stanja često se koristi header("Location: ...") za preusmeravanje. Preusmeravanje, kao i session_start, mora se desiti pre bilo kakvog ispisa u pregledač.'
                ],
                ['unset: briše jednu vrednost', 'session_destroy: završava celu sesiju', 'header Location: preusmerava korisnika']
            ],
            [
                'Sesije i kolačići',
                [
                    'Kolačić (cookie) je mali podatak koji pregledač čuva kod korisnika i šalje serveru uz naredne zahteve. Sesijski identifikator se najčešće prenosi upravo kroz kolačić, dok stvarni podaci sesije ostaju na serveru.',
                    'Za postavke kao što su izabrana tema ili jezik možeš koristiti kolačić. Za podatke prijavljenog korisnika praktičnija je sesija, jer se vrednosti ne čuvaju direktno u pregledaču.'
                ],
                ['cookie: podatak čuva pregledač', 'session: podatak čuva server', 'sesijski kolačić povezuje pregledač sa podacima na serveru']
            ],
            [
                'Pravila za bezbedan rad sa sesijama',
                [
                    'U sesiji čuvaj samo podatke koji su potrebni aplikaciji, na primer identifikator korisnika i njegovo ime. Nikada ne veruj korisničkom unosu bez provere, čak i kada dolazi od već prijavljenog korisnika.',
                    'Nakon uspešne prijave možeš pozvati session_regenerate_id(true) da se osveži sesijski identifikator. Aplikacija koja koristi prijavu mora raditi preko HTTPS veze kada se postavi na hosting.'
                ],
                ['u sesiji čuvaj samo potrebne podatke', 'proveri prava korisnika na svakoj zaštićenoj stranici', 'osveži identifikator posle prijave', 'na hostingu koristi HTTPS']
            ],
        ],
        'kod' => <<<'PHP'
<?php
session_start();

$_SESSION['ime'] = 'Ana';

if (isset($_SESSION['ime'])) {
    echo 'Prijavljen je korisnik: ' . htmlspecialchars($_SESSION['ime']);
}
?>
PHP,
        'zadatak' => 'Napravi dve stranice: prijava.php i profil.php. Na prvoj korisnik kroz formu unosi ime. Sačuvaj ga u sesiji, zatim ga na profil.php prikaži kao poruku dobrodošlice. Dodaj i link za odjavu.',
        'resenje' => 'U oba fajla pozovi session_start() na početku. U prijava.php nakon provere forme upiši $_SESSION["ime"] = $ime. U profil.php proveri isset($_SESSION["ime"]), a za odjavu pozovi session_destroy() i preusmeri korisnika na prijava.php.',
    ],
];
