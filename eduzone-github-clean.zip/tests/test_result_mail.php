<?php
require __DIR__ . '/../result_mail.php';
function mail_check(bool $ok, string $message): void {
    if (!$ok) throw new RuntimeException($message);
}
$previousFrom = getenv('EDUZONE_MAIL_FROM');
$previousLog = ini_get('error_log');
$log = tempnam(sys_get_temp_dir(), 'eduzone-mail-test-');
ini_set('error_log', $log);
try {
    putenv('EDUZONE_MAIL_FROM=no-reply@eduzone.rs');
    $calls = 0;
    $subject = "Rezultat: Čas\r\nBcc: invalid@example.com";
    $body = '<p>Učenik: probni odgovor ✅</p>';
    $result = ez_send_result_mail($subject, $body,
        function ($to, $encoded, $message, $headers, $envelope) use (&$calls, $body) {
            $calls++;
            mail_check($to === 'admin@example.invalid', 'Correct recipient');
            mail_check($envelope === '-fno-reply@eduzone.rs', 'Explicit envelope sender');
            mail_check(strpos($headers, 'From: EduZone <no-reply@eduzone.rs>') !== false, 'Matching sender');
            mail_check(base64_decode($message) === $body, 'UTF-8 body survives encoding');
            mail_check(strpos($encoded, "\n") === false, 'Subject cannot inject headers');
            mail_check(base64_decode(substr($encoded, 10, -2)) === 'Rezultat: Čas  Bcc: invalid@example.com', 'Subject encoding');
            return true;
        });
    mail_check($result['accepted'] && $calls === 1, 'Accepted response');
    $result = ez_send_result_mail('test', 'test', function () { return false; });
    mail_check(!$result['accepted'] && $result['error'] !== null, 'Rejection is recorded');
    $result = ez_send_result_mail('test', 'test', function () { throw new RuntimeException('Transport unavailable'); });
    mail_check(!$result['accepted'] && $result['error'] === 'Transport unavailable', 'Transport exception does not break results');
    $result = ez_send_result_mail('test', 'test', function () { trigger_error('sendmail failed', E_USER_WARNING); return false; });
    mail_check(!$result['accepted'] && $result['error'] === 'sendmail failed', 'Warnings are captured');
    putenv('EDUZONE_MAIL_FROM=bad@example.com -X/tmp/log');
    $result = ez_send_result_mail('test', 'test', function () { throw new RuntimeException('Must not call transport'); });
    mail_check(!$result['accepted'] && strpos($result['error'], 'Neispravna') !== false, 'Invalid envelope blocked');
    $logged = file_get_contents($log);
    mail_check(strpos($logged, '"status":"accepted"') !== false && strpos($logged, '"status":"failed"') !== false, 'Outcomes logged');
    mail_check(strpos($logged, $body) === false, 'Student answers are not logged');
    echo "Mail checks passed; no real messages sent.\n";
} finally {
    putenv($previousFrom === false ? 'EDUZONE_MAIL_FROM' : 'EDUZONE_MAIL_FROM=' . $previousFrom);
    ini_set('error_log', $previousLog);
    unlink($log);
}
