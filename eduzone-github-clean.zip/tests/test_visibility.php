<?php
require __DIR__ . '/../test_visibility.php';

function check_visibility(bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
}

$submitted = 1700000000;
$week = 7 * 24 * 60 * 60;
check_visibility(!test_history_visible($submitted, $submitted), 'Hidden immediately after submission');
check_visibility(!test_history_visible($submitted, $submitted + $week - 1), 'Hidden until seven full days');
check_visibility(test_history_visible($submitted, $submitted + $week), 'Visible at seven days');
check_visibility(test_history_visible($submitted, $submitted + $week + 1), 'Visible after seven days');
check_visibility(!test_history_visible(null, $submitted + $week), 'Unknown submission date stays hidden');
check_visibility(test_details_visible($submitted, $submitted, $submitted), 'Immediate results with submission grant');
check_visibility(test_details_visible($submitted, $submitted, $submitted + 1800), 'Grant valid for thirty minutes');
check_visibility(!test_details_visible($submitted, $submitted, $submitted + 1801), 'Expired grant cannot unlock early details');
check_visibility(!test_details_visible($submitted, null, $submitted + 1), 'No early details without grant');
check_visibility(test_details_visible($submitted, null, $submitted + $week), 'Details unlock after seven days without grant');
$grants = [test_result_key(1, 1, '2026-09-01 10:00:00') => $submitted];
$otherGrant = $grants[test_result_key(1, 1, '2026-09-10 10:00:00')] ?? null;
check_visibility(!test_details_visible($submitted, $otherGrant, $submitted), 'Old assignment cannot unlock new assignment');
check_visibility(test_result_key(1, 1, null) === test_result_key(1, 1, ''), 'Legacy assignment key remains consistent');
echo "12 visibility checks passed.\n";
