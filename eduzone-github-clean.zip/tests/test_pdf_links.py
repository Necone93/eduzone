"""Run with the conversion venv; requires PHP_BIN or php on PATH."""
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import runpy
import subprocess
import tempfile
import unittest
import uuid

import pymupdf

ROOT = Path(__file__).resolve().parents[1]
CONVERTER = runpy.run_path(str(ROOT / 'scripts/convert-lesson.py'))
PHP = os.environ.get('PHP_BIN', 'php')

class Links(unittest.TestCase):
    def test_conversion_rendering_and_cache_upgrade(self):
        with tempfile.NamedTemporaryFile(dir=ROOT / 'uploads/lekcije', suffix='.pdf', delete=False) as temp:
            source = Path(temp.name)
        cache = None
        try:
            doc = pymupdf.open()
            page = doc.new_page()
            page.insert_text((40, 55), 'Before CLICK after')
            page.insert_text((40, 80), str(uuid.uuid4()))
            click = page.search_for('CLICK')[0]
            page.insert_link({'kind': pymupdf.LINK_URI, 'from': click, 'uri': 'https://example.com/?a=1&b=2'})
            pix = pymupdf.Pixmap(pymupdf.csRGB, pymupdf.IRect(0, 0, 100, 50), False)
            pix.clear_with(150)
            page.insert_image(pymupdf.Rect(40, 100, 240, 200), stream=pix.tobytes('png'))
            page.insert_link({'kind': pymupdf.LINK_URI, 'from': pymupdf.Rect(50, 110, 120, 150), 'uri': 'https://example.org/image'})
            page.insert_link({'kind': pymupdf.LINK_URI, 'from': pymupdf.Rect(300, 100, 350, 150), 'uri': 'https://example.net/drawing'})
            page.insert_link({'kind': pymupdf.LINK_URI, 'from': pymupdf.Rect(40, 210, 80, 230), 'uri': 'javascript:alert(1)'})
            doc.save(source)
            doc.close()
            cache, data = CONVERTER['convert'](source)
            self.assertEqual(data['version'], 3)
            spans = [s for i in data['pages'][0]['items'] for line in i.get('lines', []) for s in line]
            linked = [s for s in spans if s.get('href')]
            self.assertEqual(''.join(s['text'] for s in linked), 'CLICK')
            images = [i for i in data['pages'][0]['items'] if i['type'] == 'image']
            self.assertEqual(images[0]['links'][0]['href'], 'https://example.org/image')
            self.assertEqual(data['pages'][0]['extra_links'], ['https://example.net/drawing'])
            self.assertEqual(len(data['pages'][0]['links']), 3)
            # An old cache must be upgraded by the admin's normal conversion helper.
            data['version'] = 1
            cache.write_text(json.dumps(data))
            relative = source.relative_to(ROOT).as_posix()
            code = 'require "lesson_conversion.php"; echo json_encode(ez_convert_lesson(' + json.dumps(relative) + '));'
            result = subprocess.check_output([PHP, '-r', code], cwd=ROOT, text=True)
            self.assertEqual(json.loads(result)[0], 'success')
            self.assertEqual(json.loads(cache.read_text())['version'], 3)
            code = 'require "lesson_html.php"; ez_lesson_html_render(ez_lesson_html_load(' + json.dumps(relative) + '));'
            html = subprocess.check_output([PHP, '-r', code], cwd=ROOT, text=True)
            self.assertIn('href="https://example.com/?a=1&amp;b=2"', html)
            self.assertIn('>CLICK</a>', html)
            self.assertIn('class="lesson-image-link"', html)
            self.assertNotIn('javascript:', html)
            self.assertIn('rel="noopener noreferrer"', html)
        finally:
            source.unlink(missing_ok=True)
            if cache: cache.unlink(missing_ok=True)

    def test_unsafe_destinations(self):
        for value in ['javascript:alert(1)', 'data:text/html,x', 'file:///tmp/x', '//example.com', 'https://example.com/\n', 'https://example.com/\\x']:
            self.assertIsNone(CONVERTER['web_uri'](value))
            code = 'require "lesson_html.php"; echo json_encode(ez_lesson_html_url(' + json.dumps(value) + '));'
            self.assertIsNone(json.loads(subprocess.check_output([PHP, '-r', code], cwd=ROOT)))
        code = '''require 'lesson_html.php'; echo ez_lesson_html_link('Text', 'https://example.com/"onclick="alert(1)');'''
        html = subprocess.check_output([PHP, '-r', code], cwd=ROOT, text=True)
        class Attributes(HTMLParser):
            attrs = {}
            def handle_starttag(self, tag, attrs):
                if tag == 'a': self.attrs = dict(attrs)
        parser = Attributes(); parser.feed(html)
        self.assertNotIn('onclick', parser.attrs)

if __name__ == '__main__':
    unittest.main()
