# PDF lekcije: automatski HTML prikaz

Pripremljeni su primeri „Figma – uvod i prva vežba“ i „Osnove HTML jezika“.
`lekcija.php` posle postojeće provere prijave i učitavanja lekcije iz baze prikazuje HTML ako postoji odgovarajuća konverzija. `?id=…&prikaz=pdf` vraća dosadašnji prikaz. PDF ostaje neizmenjen. Javna Digitalna učionica ne preuzima učeničke lekcije automatski.

## Konverzija

Potreban je Python 3.9+ sa zavisnostima iz `requirements-pdf.txt`:

```sh
python3 -m venv /tmp/eduzone-pdf-venv
/tmp/eduzone-pdf-venv/bin/pip install -r scripts/requirements-pdf.txt
/tmp/eduzone-pdf-venv/bin/python scripts/convert-lesson.py uploads/lekcije/IME.pdf
```

Konverter radi lokalno, bez slanja dokumenata spoljnom servisu. Izlaz je JSON u `content/lesson-html`, imenovan SHA-256 otiskom PDF-a. Promenjen PDF ne koristi staru konverziju. PHP serveru nije potreban Python za prikaz već konvertovanih lekcija. Pri prenosu sajta preneti i ove JSON fajlove, `.htaccess`, `lesson_html.php`, izmenjeni `lekcija.php` i `assets/css/lesson-html.css`.

`content/lesson-html/.htaccess` zabranjuje direktan HTTP pristup konverzijama na Apache-u. Ako se koristi drugi server, isti direktorijum mora biti blokiran njegovom konfiguracijom.

## Šta treba proveriti

- Tekst je pravi HTML, slike su PNG isečci izvornog dokumenta.
- Svaka stranica ima sklopivi original radi poređenja, uključujući vektorske crteže i tabele.
- Redosled blokova, naslovi i kod određuju se heuristički. Višekolonski dokumenti, tabele, formule i crteži mogu zahtevati ručnu obradu. Raspored nije identičan PDF-u.
- Skenirane strane bez teksta prikazuju se kao slike; OCR nije implementiran.
- Uvoz proizvoljnog HTML-a nije dozvoljen: svi tekstovi se escapuju pri prikazu.
- Admin upload automatski pokreće konverziju nakon čuvanja lekcije. Za postojeće lekcije koristi „Pripremi HTML“. Konverzija traje najviše 20 sekundi; neuspeh ostavlja PDF dostupan i prikazuje upozorenje. HTML se prikazuje odmah nakon uspešne konverzije, bez zasebnog odobravanja nacrta.

Proveriti izgled svake konverzije pre prenosa na produkciju. Trenutno su namerno konvertovana samo dva primerka.

## Podešavanje servera

Lokalni XAMPP koristi `.runtime/pdf-venv/bin/python`. Ovaj direktorijum je izuzet iz Git-a i blokiran za HTTP. Lokalna zavisnost PyMuPDF 1.26.5 je postavljena, a korisnik Apache-a `daemon` ima ACL dozvolu pisanja u `content/lesson-html`.

Na produkcionom serveru napraviti poseban Python 3.9+ venv (ne kopirati macOS venv na Linux), instalirati `scripts/requirements-pdf.txt` i zadati punu putanju Python-a preko serverske promenljive `EDUZONE_PDF_PYTHON`, ili koristiti `.runtime/pdf-venv/bin/python` u projektu. Ako je `.runtime` unutar web korena, postaviti `.runtime/.htaccess` sa `Require all denied`. Server mora dozvoljavati PHP `proc_open`, a njegov korisnik mora imati pisanje u `content/lesson-html` i čitanje PDF-ova i konvertera. Ne davati javne HTTP dozvole direktorijumu konverzija.

Ako ove mogućnosti nisu dostupne na hostingu, upload ostaje uspešan, uz upozorenje da konverter nije podešen. Serveru nije potrebno pokretanje Python-a pri svakom otvaranju već konvertovane lekcije.

## Linkovi iz PDF-a

Verzija 2 konverzije čuva ugrađene HTTP/HTTPS linkove: tekstualne linkove (i kada je klikabilan samo deo rečenice), klikabilne zone slika i linkove preko originalne stranice. Eksterne stranice otvaraju se u novoj kartici. Ako link ne može da se poveže sa izdvojenim tekstom ili slikom, nalazi se u listi „Linkovi sa ove strane“. Običan tekst koji liči na adresu, ali nema PDF link anotaciju, ne dobija automatski odredište.

Postojeće verzije 1 i dalje mogu da se čitaju; „Pripremi HTML“ ih sada nadograđuje na verziju 2. Nove otpremljene lekcije automatski koriste verziju 2.

Test: `PHP_BIN=/putanja/do/php .runtime/pdf-venv/bin/python -B tests/test_pdf_links.py`.

## Tabele

Od verzije 3, konverter prepoznaje tabele koje PDF jasno označava linijama i prikazuje ih kao prilagodljivu sliku originalne tabele. Tako se čuvaju redovi, kolone i spajanje ćelija, dok ostatak lekcije ostaje HTML tekst. Učenik na telefonu može vodoravno da pomeri samo široku tabelu. Za već postojeću lekciju klikni „Pripremi HTML“ da bi se napravila nova verzija.

## Namecheap paket

Preneti i `lesson_python.php`. Konverter i dijagnostika sada automatski traže cPanel okruženje `virtualenv/eduzone_pdf/3.11/bin/python` u roditeljskom folderu sajta (za ovaj nalog `/home/ACCOUNT/virtualenv/eduzone_pdf/3.11/bin/python`). Eksplicitna promenljiva `EDUZONE_PDF_PYTHON` ima prednost. Lokalni venv ostaje podržan.
