#!/usr/bin/env python3
"""Create a local, non-executable HTML-reader cache; never modifies the source PDF."""
import argparse
import base64
from collections import Counter
import hashlib
import json
from pathlib import Path
import tempfile
from urllib.parse import urlsplit
import pymupdf

ROOT = Path(__file__).resolve().parents[1]

def web_uri(value):
    if not isinstance(value, str) or any(ord(c) <= 32 for c in value) or "\\" in value:
        return None
    try:
        parsed = urlsplit(value)
        return value if parsed.scheme.lower() in ('http', 'https') and parsed.hostname else None
    except ValueError:
        return None


def page_links(page):
    return [{'href': link['uri'], 'rect': pymupdf.Rect(link['from']), 'used': False}
            for link in page.get_links() if web_uri(link.get('uri'))]


def linked_spans(span, links):
    """Split at character boundaries so a link never swallows adjacent plain text."""
    groups = []
    for char in span['chars']:
        box = pymupdf.Rect(char['bbox'])
        center = (box.tl + box.br) / 2
        href = None
        for link in links:
            if link['rect'].contains(center):
                href = link['href']
                link['used'] = True
                break
        if groups and groups[-1].get('href') == href:
            groups[-1]['text'] += char['c']
        else:
            groups.append({'text': char['c'], 'bold': bool(span['flags'] & 16),
                           'italic': bool(span['flags'] & 2), 'href': href})
    return groups


def image_links(rect, links):
    result = []
    for link in links:
        hit = rect & link['rect']
        if hit.is_empty or rect.is_empty:
            continue
        link['used'] = True
        result.append({'href': link['href'], 'left': 100 * (hit.x0 - rect.x0) / rect.width,
                       'top': 100 * (hit.y0 - rect.y0) / rect.height,
                       'width': 100 * hit.width / rect.width, 'height': 100 * hit.height / rect.height})
    return result

def png(page, rect=None, scale=1.5):
    region = rect or page.rect
    scale = min(scale, 2400 / max(region.width, region.height, 1))
    return base64.b64encode(page.get_pixmap(matrix=pymupdf.Matrix(scale, scale), clip=rect, alpha=False).tobytes('png')).decode('ascii')


def detected_tables(page):
    """Return visible table regions. A PDF table has no semantic table markup,
    so preserving its rendered layout is more reliable than flattening cells."""
    try:
        return [pymupdf.Rect(table.bbox) & page.rect for table in page.find_tables().tables]
    except Exception:
        return []


def overlaps_table(rect, tables):
    """Treat a source block as part of a table when most of it sits in one."""
    for table in tables:
        overlap = rect & table
        if not overlap.is_empty and (overlap.width * overlap.height) / max(rect.width * rect.height, 1) > .55:
            return True
    return False

def convert(source):
    source = source.resolve()
    if not source.is_relative_to(ROOT / 'uploads' / 'lekcije') or source.suffix.lower() != '.pdf':
        raise ValueError('Source must be a PDF in uploads/lekcije.')
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    document = pymupdf.open(source)
    if document.needs_pass:
        raise ValueError('Password-protected PDFs are not supported.')
    if len(document) > 150:
        raise ValueError('Maximum 150 pages per conversion.')
    pages = []
    image_bytes = 0
    for page in document:
        blocks = page.get_text('rawdict', sort=True)['blocks']
        links = page_links(page)
        table_rects = detected_tables(page)
        for block in blocks:
            for line in block.get('lines', []):
                for span in line['spans']:
                    span['text'] = ''.join(char['c'] for char in span['chars'])
        sizes = Counter()
        for block in blocks:
            for line in block.get('lines', []):
                for span in line['spans']:
                    sizes[round(span['size'])] += len(span['text'].strip())
        body_size = sizes.most_common(1)[0][0] if sizes else 12
        items = []
        for rect in table_rects:
            if not rect.is_empty:
                items.append({
                    'type': 'table', 'rect': list(rect), 'png': png(page, rect),
                    'links': image_links(rect, links),
                })
        for block in blocks:
            block_rect = pymupdf.Rect(block['bbox']) & page.rect
            if not block_rect.is_empty and overlaps_table(block_rect, table_rects):
                continue
            if block['type'] == 1:
                # Render the visible region to preserve image masks and overlaid labels.
                rect = pymupdf.Rect(block['bbox']) & page.rect
                if not rect.is_empty:
                    items.append({'type': 'image', 'rect': list(rect), 'png': png(page, rect), 'width': round(rect.width * 1.5), 'height': round(rect.height * 1.5), 'links': image_links(rect, links)})
                continue
            lines = []
            font_sizes = []
            mono_chars = total_chars = 0
            for line in block.get('lines', []):
                spans = []
                for span in line['spans']:
                    text = span['text']
                    if not text.strip():
                        if spans: spans.append({'text': text, 'bold': False, 'italic': False})
                        continue
                    font_sizes.append(span['size'])
                    total_chars += len(text)
                    if span['flags'] & 8: mono_chars += len(text)
                    spans.extend(linked_spans(span, links))
                if spans: lines.append(spans)
            if not lines: continue
            plain = '\n'.join(''.join(s['text'] for s in line) for line in lines)
            kind = 'code' if mono_chars > total_chars * .6 else 'paragraph'
            if kind != 'code' and max(font_sizes, default=0) >= body_size * 1.2 and len(plain) < 220:
                kind = 'heading'
            items.append({'type': kind, 'lines': lines, 'rect': list(block_rect)})
        items.sort(key=lambda item: (item.get('rect', [0, 0])[1], item.get('rect', [0, 0])[0]))
        pages.append({'number': page.number + 1, 'items': items, 'original': png(page), 'has_text': bool(page.get_text().strip()),
                      'extra_links': list(dict.fromkeys(link['href'] for link in links if not link['used'])),
                      'links': image_links(page.rect, [{'href': link['href'], 'rect': link['rect'] * page.rotation_matrix} for link in links])})
        image_bytes += len(pages[-1]['original']) + sum(len(item.get('png', '')) for item in items)
        if image_bytes > 32 * 1024 * 1024:
            raise ValueError('HTML output exceeds 32 MB. Split the document.')
    payload = {'version': 3, 'sha256': digest, 'source': source.name, 'pages': pages}
    target_dir = ROOT / 'content' / 'lesson-html'
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / (digest + '.json')
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=target_dir, delete=False) as temp:
        json.dump(payload, temp, ensure_ascii=False)
        temporary = Path(temp.name)
    # NamedTemporaryFile starts at 0600; Apache runs as a different user.
    # HTTP access remains blocked by this directory's .htaccess.
    temporary.chmod(0o644)
    temporary.replace(target)
    document.close()
    return target, payload

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pdf', type=Path, nargs='+')
    args = parser.parse_args()
    for source in args.pdf:
        target, data = convert(source)
        print(f'{source.name}: {len(data["pages"])} pages, {sum(i["type"] == "image" for p in data["pages"] for i in p["items"])} images -> {target.relative_to(ROOT)}')
